import streamlit as st
from PIL import Image
import os

st.set_page_config(page_title="Reverse Product Search", layout="wide")

# Product Database
products = [
    {
        "name": "Black Dress",
        "category": "Fashion",
        "keywords": ["dress", "black dress", "women", "fashion"],
        "image": "products/dress.jpg"
    },
    {
        "name": "Wireless Keyboard",
        "category": "Electronics",
        "keywords": ["keyboard", "wireless keyboard", "computer"],
        "image": "products/keyboard.jpg"
    },
    {
        "name": "AirPods",
        "category": "Electronics",
        "keywords": ["earphones", "airpods", "wireless"],
        "image": "products/airpods.jpg"
    },
    {
        "name": "Watch",
        "category": "Accessories",
        "keywords": ["watch", "wrist watch"],
        "image": "products/watch.jpg"
    },
    {
        "name": "Bag",
        "category": "Fashion",
        "keywords": ["bag", "backpack", "handbag"],
        "image": "products/bag.jpg"
    },
    {
        "name": "Socks",
        "category": "Fashion",
        "keywords": ["socks", "cotton socks"],
        "image": "products/socks.jpg"
    }
]

st.title("🔍 Reverse Product Search")

query = st.text_input("Search Product")

if st.button("Search"):

    query = query.lower().strip()

    found = False

    cols = st.columns(3)

    index = 0

    for product in products:

        if any(query in keyword for keyword in product["keywords"]):

            with cols[index % 3]:

                if os.path.exists(product["image"]):
                    img = Image.open(product["image"])
                    img = img.resize((220,220))
                    st.image(img)

                st.subheader(product["name"])
                st.write("Category:", product["category"])

            index += 1
            found = True

    if not found:
        st.error("No matching products found.")