import streamlit as st
from PIL import Image
import os

# Page Configuration
st.set_page_config(page_title="Smart Product Recommendation Engine", layout="wide")

# Recommendation Data
recommendations = {
    "Handbags": ["Dresses", "Watch"],
    "Laptop": ["Keyboard", "Mouse"],
    "Mobile": ["Earphones", "Phone Case"],
    "Shoes": ["Socks", "Bag"]
}

# Image Paths
image_paths = {
    "Dresses": "dress.png",
    "Watch": "watch.jpg",

    "Keyboard": "keyboard.png",
    "Mouse": "mouse.jpg",

    "Earphones": "airpods.jpg",
    "Phone Case": "case.png",

    "Socks": "socks.jpg",
    "Bag": "bag.jpg"
}

# Title
st.title("🛍 Smart Product Recommendation Engine")

st.write("Select a product to view complementary products that are frequently bought together.")

# Dropdown
product = st.selectbox(
    "Select a Product",
    list(recommendations.keys())
)

# Button
if st.button("Recommend Products"):

    st.success(f"Selected Product: **{product}**")

    st.subheader("Frequently Bought Together")

    items = recommendations[product]

    cols = st.columns(len(items))

    for col, item in zip(cols, items):

        with col:

            path = image_paths.get(item)

            if path and os.path.exists(path):

                img = Image.open(path)

                # Resize image
                img = img.resize((220, 220))

                st.image(img)

            else:
                st.warning(f"Image not found for {item}")

            st.markdown(f"### {item}")