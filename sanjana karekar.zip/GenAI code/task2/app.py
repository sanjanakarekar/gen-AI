import streamlit as st
from PIL import Image
import imagehash
import os
import shutil

st.set_page_config(page_title="Unique Product Catalog", layout="wide")

st.title("Unique Product Catalog Creation")

input_folder = "products"
output_folder = "unique_products"

os.makedirs(output_folder, exist_ok=True)

if st.button("Generate Unique Catalog"):

    hashes = {}

    duplicate_count = 0
    unique_count = 0

    for file in os.listdir(input_folder):

        path = os.path.join(input_folder, file)

        img = Image.open(path)

        h = imagehash.average_hash(img)

        if h not in hashes:

            hashes[h] = file

            shutil.copy(path, os.path.join(output_folder, file))

            unique_count += 1

        else:

            duplicate_count += 1

    st.success("Catalog Created Successfully!")

    st.write("### Results")

    st.write(f"Unique Products : {unique_count}")
    st.write(f"Duplicate Products Removed : {duplicate_count}")

    st.subheader("Unique Catalog")

    cols = st.columns(4)

    i = 0

    for file in os.listdir(output_folder):

        with cols[i % 4]:

            img = Image.open(os.path.join(output_folder, file))

            st.image(img, caption=file)

        i += 1